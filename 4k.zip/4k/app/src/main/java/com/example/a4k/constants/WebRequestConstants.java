package com.example.a4k.constants;

/**
 * Common web request urls
 */
public interface WebRequestConstants {
    String END_POINT_PROFILE = "https://randomuser.me/api/";
}