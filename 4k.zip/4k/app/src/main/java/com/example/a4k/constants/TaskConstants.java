package com.example.a4k.constants;

/**
 * Tasks constants
 */
public interface TaskConstants {
    int WS_GET_PROFILE = 1;
    int WS_GET_USERS = 2;
}