package com.example.a4k.constants;

public interface PreferenceConstants {
    String PREF_NAME = "PaxBat";
    String LOGIN_STATUS = "login_status";
}
